import { Component, OnInit } from '@angular/core';
import { EmployeesService } from 'src/app/services/employees.service';
import { Employee } from '../../models/employee.model';

@Component({
  selector: 'app-employees-listar',
  templateUrl: './employees-listar.component.html',
  styleUrls: ['./employees-listar.component.css']
})
export class EmployeesListarComponent implements OnInit {
  listaemployees: Employee[] = [];
  constructor(private employeesService: EmployeesService) { }

  ngOnInit(): void {
    this.cargar();
  }

  cargar() {
    this.employeesService.getEmpleados().subscribe(
      (res) => {
        this.listaemployees=res;
      }
    );
  }
}
