import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeesService } from 'src/app/services/employees.service';
import { Employee } from '../../models/employee.model';

@Component({
  selector: 'app-employees-crear',
  templateUrl: './employees-crear.component.html',
  styleUrls: ['./employees-crear.component.css']
})
export class EmployeesCrearComponent implements OnInit {
  createEmployee!: FormGroup;
  submited: boolean = false;
  constructor(private formBuilder: FormBuilder,
    private employeesService: EmployeesService,
    private router: Router) {

    this.createEmployee = formBuilder.group({   
      name: ['', Validators.required]
    });
  }

  ngOnInit(): void {
  }
  agregar() {
    this.submited = true;
    if (this.createEmployee.invalid) return;
    const employee: Employee = {
      id: 0,
      name: this.createEmployee.value.name,
    };
    this.employeesService
      .postEmpleados(employee)
      .subscribe((res) => this.router.navigate(['/employeeslistar']));
  }
}
