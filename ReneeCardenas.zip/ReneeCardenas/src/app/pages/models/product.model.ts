export class Product{
    constructor(
        public id: number,
        public name: string,
        public price: number
    ){}
  }
  export class PaginaProduct{
    constructor(
      public data: Product[]
    ) {}
  }
  