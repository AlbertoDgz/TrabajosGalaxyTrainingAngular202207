import { Sale } from "./sale.model";

export class PaginaSale{
  constructor(
    public totalReg: number,
    public pagActual: number,
    public regXPag: number,
    public data: Sale[]
  ) {}
}
