export class Employee{
    constructor(
        public id: number,
        public name: string,
    ){}
  }
  export class PaginaEmployee {
    constructor(
      public data: Employee[]
    ) {}
  }
  