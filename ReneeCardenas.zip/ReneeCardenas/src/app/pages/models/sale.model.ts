export class Sale {
    constructor(
        public id: number,
        public date: string,
        public unitPrice: number,
        public quantity: number,
        public totalPrice: number,
        public idEmployee: number,
        public nameEmployee: string,
        public idProduct: number,
        public nameProduct: string,
        public idCustomer: number,
        public nameCustomer: string,

    ) { }
}
