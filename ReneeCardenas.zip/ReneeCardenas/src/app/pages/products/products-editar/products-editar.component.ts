import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductsService } from 'src/app/services/products.service';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-products-editar',
  templateUrl: './products-editar.component.html',
  styleUrls: ['./products-editar.component.css']
})
export class ProductsEditarComponent implements OnInit {
  id!: number;
  form!: FormGroup;
  submited: boolean = false;
  constructor(
    private productService: ProductsService,
    private router: Router,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute
  ) {
    this.form = formBuilder.group({
      id: ['', Validators.required],
      name: ['', Validators.required],
      price: ['', Validators.required]
    });

  }

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.params['id'];
    console.log(this.id);

    this.productService.getById(this.id).subscribe(res => {
      this.form.setValue({
        id: res.id,
        name: res.name,
        price: res.price
      });
    });


  }
  updateProduct() {
    this.submited = true;
    const product: Product = {
      id: this.form.value.id,
      name: this.form.value.name,
      price: this.form.value.price
    }
    this.productService
      .update(product)
      .subscribe((res) => this.router.navigate(['/productlistar']));
  }
}
