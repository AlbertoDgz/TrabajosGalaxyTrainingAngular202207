import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-products-listar',
  templateUrl: './products-listar.component.html',
  styleUrls: ['./products-listar.component.css']
})
export class ProductsListarComponent implements OnInit {
  lista: Product[] = [];
  constructor(private productsService: ProductsService) { }

  ngOnInit(): void {
    this.cargar();
  }

  cargar() {
    this.productsService.getProduct().subscribe(
      (res) => {
        this.lista=res;
      }
    );
  }
  deleteProduct(id:number){
    this.productsService.delete(id).subscribe(res=>{
      console.log(id); 
      this.cargar();
      
    });
  }
}
