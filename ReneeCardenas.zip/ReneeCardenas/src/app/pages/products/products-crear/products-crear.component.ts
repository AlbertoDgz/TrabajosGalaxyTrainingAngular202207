import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProductsService } from 'src/app/services/products.service';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-products-crear',
  templateUrl: './products-crear.component.html',
  styleUrls: ['./products-crear.component.css']
})
export class ProductsCrearComponent implements OnInit {
  createProduct!: FormGroup;
  submited: boolean = false;
  constructor(private formBuilder: FormBuilder,
    private productsService: ProductsService,
    private router: Router) {

    this.createProduct = formBuilder.group({    
      name: ['', Validators.required],
      price: ['', Validators.required]
    });
  }

  ngOnInit(): void {
  }
  agregar() {
    this.submited = true;
    if (this.createProduct.invalid) return;
    const product: Product = {
      id: 0,
      name: this.createProduct.value.name,
      price: this.createProduct.value.price,
    };
    this.productsService
      .postProduct(product)
      .subscribe((res) => this.router.navigate(['/productlistar']));
  }
}
