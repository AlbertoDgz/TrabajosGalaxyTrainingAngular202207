import { Component, OnInit } from '@angular/core';
import { SalesService } from 'src/app/services/sales.service';
import { Sale } from '../../models/sale.model';
import { PageEvent } from '@angular/material/paginator';

@Component({
  selector: 'app-sale-listar',
  templateUrl: './sale-listar.component.html',
  styleUrls: ['./sale-listar.component.css']
})
export class SaleListarComponent implements OnInit {

  listarsale: Sale[] = [];
  pagActual: number = 1;
  regXPag: number = 5;
  totalReg!: number;
  totalPags!: number;

  pageSizeOptions: number[] = [5, 10, 15, 20];
  pageEvent!: PageEvent;

  handlePages(e: PageEvent) {
    this.totalPags = e.length;
    this.regXPag = e.pageSize;
    this.pagActual = e.pageIndex + 1;

    this.cargarRegistros();
  }

  constructor(private salesService: SalesService) {}

  ngOnInit(): void {
    console.log('ingreso a ngOnInit');
    this.cargarRegistros();
  }

  cargarRegistros() {
    this.salesService
      .get(this.pagActual, this.regXPag)
      .subscribe((res) => {
        this.listarsale = res.data;
        this.pagActual = res.pagActual;
        this.regXPag = res.regXPag;
        this.totalReg = res.totalReg;
        if (this.totalReg % this.regXPag > 0)
          this.totalPags = Math.round(this.totalReg / this.regXPag) + 1;
        else this.totalPags = Math.round(this.totalReg / this.regXPag);
      });
  }

  cambiarPagina(valor: number) {
    this.pagActual += valor;
    if (this.pagActual <= 0) this.pagActual = 1;
    if (this.pagActual >= this.totalPags) this.pagActual = this.totalPags;
    this.cargarRegistros();
  }

}
