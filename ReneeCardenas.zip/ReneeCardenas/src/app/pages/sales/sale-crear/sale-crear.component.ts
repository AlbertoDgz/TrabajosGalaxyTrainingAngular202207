import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sale-crear',
  templateUrl: './sale-crear.component.html',
  styleUrls: ['./sale-crear.component.css']
})
export class SaleCrearComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
