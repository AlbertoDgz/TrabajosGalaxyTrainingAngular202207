import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PaginaSale } from '../pages/models/pagina-sale.model';

@Injectable({
  providedIn: 'root'
})
export class SalesService {
  URL: string = 'http://localhost:5292/sale/';
  
  constructor(private http: HttpClient) {}

  get(npag: number, rxpag: number): Observable<PaginaSale> {
    const httpParams = new HttpParams({
      fromObject: {
        nropag: npag,
        regxpag: rxpag,
      },
    });
    return this.http.get<PaginaSale>(this.URL, { params: httpParams });
  }

 
}
