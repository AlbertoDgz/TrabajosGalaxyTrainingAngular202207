import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Employee, PaginaEmployee } from '../pages/models/employee.model';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class EmployeesService {
  URL: string = 'http://localhost:5292/employee/';
  constructor(private http: HttpClient) { }
  
  getEmpleados(): Observable<Employee []> {
    
    return this.http.get<Employee []>(this.URL);
  }

  postEmpleados(employee: Employee):Observable<Employee>{
    return this.http.post<Employee>(this.URL,employee)
  }
}
