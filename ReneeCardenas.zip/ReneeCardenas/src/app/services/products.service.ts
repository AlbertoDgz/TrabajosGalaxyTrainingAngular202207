import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../pages/models/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  URL: string = 'http://localhost:5292/product';
  constructor(private http: HttpClient) { }

  getProduct(): Observable<Product[]> {
    return this.http.get<Product[]>(this.URL);
  }

  postProduct(product: Product): Observable<Product> {
    return this.http.post<Product>(this.URL, product)
  }
  getById(id: number): Observable<Product> {
    console.log("service"+id);
    let urlGet= this.URL+"/"+id;
    return this.http.get<Product>(urlGet);
  }
  update(product: Product): Observable<Product> {
    console.log(product);
    return this.http.put<Product>(this.URL, product);
  }

  delete(id: number): Observable<Product> {   
    let urldelete= this.URL+"/"+id;
    return this.http.delete<Product>(urldelete);
  }

}
