import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ProductsListarComponent } from './pages/products/products-listar/products-listar.component';
import { ProductsCrearComponent } from './pages/products/products-crear/products-crear.component';
import { EmployeesListarComponent } from './pages/employees/employees-listar/employees-listar.component';
import { EmployeesCrearComponent } from './pages/employees/employees-crear/employees-crear.component';
import { SharedModule } from './shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SaleListarComponent } from './pages/sales/sale-listar/sale-listar.component';
import { SaleCrearComponent } from './pages/sales/sale-crear/sale-crear.component';
import {MatPaginatorModule} from '@angular/material/paginator';
import { ProductsEditarComponent } from './pages/products/products-editar/products-editar.component';
@NgModule({
  declarations: [
    AppComponent,
    ProductsListarComponent,
    ProductsCrearComponent,
    EmployeesListarComponent,
    EmployeesCrearComponent,
    SaleListarComponent,
    SaleCrearComponent,
    ProductsEditarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    SharedModule,
    HttpClientModule,    
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatPaginatorModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
