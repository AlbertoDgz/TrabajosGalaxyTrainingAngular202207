import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeesCrearComponent } from './pages/employees/employees-crear/employees-crear.component';
import { EmployeesListarComponent } from './pages/employees/employees-listar/employees-listar.component';
import { ProductsCrearComponent } from './pages/products/products-crear/products-crear.component';
import { ProductsEditarComponent } from './pages/products/products-editar/products-editar.component';
import { ProductsListarComponent } from './pages/products/products-listar/products-listar.component';
import { SaleCrearComponent } from './pages/sales/sale-crear/sale-crear.component';
import { SaleListarComponent } from './pages/sales/sale-listar/sale-listar.component';

const routes: Routes = [

  { path: 'employeeslistar', component: EmployeesListarComponent },
  { path: 'employeescrear', component: EmployeesCrearComponent },
  { path: 'productlistar', component: ProductsListarComponent },
  { path: 'productcrear', component: ProductsCrearComponent },
  { path: 'productedit/:id', component: ProductsEditarComponent },
  { path: 'salelistar', component: SaleListarComponent },
  { path: 'salecrear', component: SaleCrearComponent },
  { path: '', redirectTo: 'employeeslistar', pathMatch: 'full' },
  { path: '**', redirectTo: 'employeeslistar', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
